﻿using System.Windows.Controls;

namespace MaterialDesignDemo.TransitionsDemo
{
    /// <summary>
    /// Interaction logic for Slide3_Intro.xaml
    /// </summary>
    public partial class Slide3_Intro : UserControl
    {
        public Slide3_Intro()
        {
            InitializeComponent();
        }
    }
}
