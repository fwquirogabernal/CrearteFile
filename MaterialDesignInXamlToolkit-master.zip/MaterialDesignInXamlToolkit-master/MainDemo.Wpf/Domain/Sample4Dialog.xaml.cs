﻿using System.Windows.Controls;

namespace MaterialDesignColors.WpfExample.Domain
{
    /// <summary>
    /// Interaction logic for SampleDialog.xaml
    /// </summary>
    public partial class Sample4Dialog : UserControl
    {
        public Sample4Dialog()
        {
            InitializeComponent();
        }
    }
}
