﻿using System.Windows.Controls;

namespace MaterialDesignColors.WpfExample.Domain
{
    /// <summary>
    /// Interaction logic for SampleMessageDialog.xaml
    /// </summary>
    public partial class SampleMessageDialog : UserControl
    {
        public SampleMessageDialog()
        {
            InitializeComponent();
        }
    }
}
