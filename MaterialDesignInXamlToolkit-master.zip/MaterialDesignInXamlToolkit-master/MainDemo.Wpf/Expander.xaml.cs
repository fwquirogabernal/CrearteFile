﻿using System.Windows.Controls;

namespace MaterialDesignColors.WpfExample
{
    /// <summary>
    /// Interaktionslogik für Expander.xaml
    /// </summary>
    public partial class Expander : UserControl
    {
        public Expander()
        {
            InitializeComponent();
        }
    }
}
